function [K,Phi,W,b] = compute_kernel_matrix(X, D, sigma)
    % Inputs:
    % X - Input dataset (n x d), where n is the number of samples
    % D - Number of random Fourier features
    % sigma - Gaussian kernel width

    % Step 1: Generate random Fourier features
    [~, d] = size(X);

    W = (1 / sigma) * randn(d, D); % Random projection matrix
    b = 2 * pi * rand(1, D);       % Random biases


    
    Phi = sqrt(2 / D) * cos(X * W + b); % Feature map matrix (n x D)

    K = (2 / D) * cos(X * W + b) * cos(X * W + b)';
end


