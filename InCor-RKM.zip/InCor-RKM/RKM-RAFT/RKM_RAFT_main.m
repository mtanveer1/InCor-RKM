clc; clear all; close all;
load('Train.txt')
load('Test.txt')
[samples_train, features_train]=size(Train);
[samples_test, features_test]=size(Train);
samples=samples_train+samples_test;
features=features_train+features_test;
D=  round(sqrt(samples*log(features)));
FunPara.c_1=1;
FunPara.kerfpara.pars=2;
FunPara.kerfpara.type='rbf';
FunPara.d=D;

[accuracy,time] =  RKM_RAFT_classification(Train, Test, FunPara.c_1, 10^-5, FunPara.kerfpara,FunPara.d);


accuracy