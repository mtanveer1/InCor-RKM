function x_approx = solve_with_svd(A, b, r)
    % A: n x n matrix
    % b: n x 1 vector
    % r: number of singular values to keep (r << n)
    
    % Step 1: Perform Singular Value Decomposition (SVD)
    [U_r, S_r, V_r] = randomizedSVD(A,r);  % A = U S V'
    
    % % Step 2: Truncate the SVD to keep only the first r singular values
    % U_r = U(:, 1:r);      % n x r matrix
    % S_r = S(1:r, 1:r);    % r x r diagonal matrix
    % V_r = V(:, 1:r);      % n x r matrix
    
    % Step 3: Approximate A^-1 using the truncated SVD components
    A_inv_approx = V_r * inv(S_r) * U_r';  % n x n approximation of A^-1
    
    % Step 4: Solve the system A x = b using the approximate A^-1
    x_approx = A_inv_approx * b;
end
