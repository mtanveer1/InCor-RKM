function [U, S, V] = randomizedSVD(A, r)
    % Inputs:
    % A - Input matrix (m x n)
    % r - Desired rank approximation
    %
    % Outputs:
    % U - Left singular vectors (m x r)
    % S - Singular values (r x r)
    % V - Right singular vectors (n x r)

    [~, n] = size(A);
    
    % Step 1: Generate a random Gaussian matrix
    Omega = randn(n, r);  % Size (n x r)
    
    % Step 2: Compute Y = A * Omega (project A onto a lower-dimensional space)
    Y = A * Omega;  % Size (m x r)
    
    % Step 3: Perform QR decomposition to get orthonormal basis
    [Q, ~] = qr(Y, 0);  % Q is size (m x r)
    
    % Step 4: Compute the smaller matrix B = Q' * A
    B = Q' * A;  % Size (r x n)
    
    % Step 5: Compute SVD of the small matrix B
    [U_tilde, S, V] = svd(B, 'econ');  % 'econ' ensures efficiency
    
    % Step 6: Approximate the left singular vectors of A
    U = Q * U_tilde;  % Size (m x r)
    
    % Return U, S, V
end
