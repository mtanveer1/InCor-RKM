function [accuracy, Time] = RKMRFS_classification(train, Test, eeta, Lamda, kerfpara,D)

% Extract training data and labels
eetaby1 = 1 / eeta;
clear eeta
train_data = train(:, 1:end-1);
Y = train(:, end);
TestX = Test(:, 1:end-1);
obs1 = Test(:, end);

% Start measuring the time
start_time = tic;

% Number of training samples
p = size(train_data, 1);

% Reshape Y and obs1 to column vectors
Y = reshape(Y, [], 1);
obs1 = reshape(obs1, [], 1);

[mat,phi_tr,W,b,idx]=compute_kernel_matrix2(train_data,D,kerfpara.pars);
MT1 = Y(idx);
zero_array = zeros(size(MT1, 2), 1);
MT1_combined = [MT1; zero_array];  % Combine the target and zero vector
clear MT1 zero_array train_data

e = ones(size(mat,1), 1);
mat=eetaby1 * mat;
iii=eye(size(mat,1));
iii=Lamda*iii;
mat= mat + iii;

% Append e as a new column
mat = [mat, e];
m2=[e' 0];
clear e
mat = [mat;m2];
%%  Compute the solution MT1_b1 using matrix inversion
MT1_b1 = mat\MT1_combined;
h1 = MT1_b1(1:end-1, :);
b1 = MT1_b1(end, :);


%%  W and b are already computed during training phase
%phi_test = sqrt(2/D) * [cos(TestX * W + b)];
phi_test = sqrt(2 / D) * cos(W'*TestX'  + b');  % Transform test data using the same W and b
mat_test=phi_test'* phi_tr(idx, :)';

% Compute raw scores for classification
raw = mat_test * h1 + b1;

% Perform classification (1 for positive, -1 for negative)
assigned_label = zeros(size(raw, 1), 1);
for i = 1:size(raw, 1)
    if raw(i) >= 0
        assigned_label(i) = 1;  % Assign label 1 if score is non-negative
    else
        assigned_label(i) = -1; % Assign label -1 if score is negative
    end
end

% Compute accuracy
accuracy = sum(assigned_label == obs1) / length(obs1) * 100;

% Measure the time taken
Time = toc(start_time);
end