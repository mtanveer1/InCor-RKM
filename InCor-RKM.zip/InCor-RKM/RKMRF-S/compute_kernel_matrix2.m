function [K,Phi,W,b,idx] = compute_kernel_matrix2(X, D, sigma)
% Inputs:
% X - Input dataset (n x d), where n is the number of samples
% D - Number of random Fourier features
% sigma - Gaussian kernel width

% Step 1: Generate random Fourier features
[n, d] = size(X);
m=round(0.1*n);
W = (1 / sigma) * randn(d, D); % Random projection matrix
b = 2 * pi * rand(1, D);       % Random biases
Phi = sqrt(2 / D) * cos(X * W + b); % Feature map matrix (n x D)
idx = randperm(n, m);               % Random indices without replacement
Phi_reduced = Phi(idx, :);          % Reduced matrix (m x D)

% Step 2: Compute approximate kernel matrix
K = Phi_reduced * Phi_reduced'; % Approximation of the Gaussian kernel matrix
end


