function [accuracy, Time] = InCor_RKM_classification(trainall, Test, eeta, Lamda, kerfpara,D)


% Extract training data and labels
eetaby1 = 1 / eeta;
clear eeta
train_data_all = trainall(:, 1:end-1);
[m, ~] = size(train_data_all);
sam_selec=round(0.1*m);
num_clus=round(0.03*m);
nys_landmark=round(0.01*m);
Y_all = trainall(:, end);
[selected]= InCor(train_data_all, sam_selec, num_clus, nys_landmark, kerfpara.pars, Lamda);

train_data=train_data_all(selected,:);
Y=Y_all(selected,:);
TestX = Test(:, 1:end-1);        
obs1 = Test(:, end);             

% Start measuring the time
start_time = tic;

% Number of training samples
p = size(train_data, 1);

% Reshape Y and obs1 to column vectors
Y = reshape(Y, [], 1);
obs1 = reshape(obs1, [], 1);

% Initialize vector e (used for matrix construction)
e = ones(p, 1);
MT1 = Y;
zero_array = zeros(size(MT1, 2), 1);
MT1_combined = [MT1; zero_array];
clear MT1 zero_array

[mat,phi_tr,W,b]=compute_kernel_matrix(train_data,D,kerfpara.pars);

clear train_data

mat=eetaby1 * mat;
iii=eye(p);
iii=Lamda*iii;
mat= mat + iii;

% Append e as a new column
mat = [mat, e];
m2=[e' 0];
clear e
mat = [mat;m2];

%% Compute the solution MT1_b1 using matrix inversion  % RKMRF
MT1_b1 = mat\MT1_combined;
h1 = MT1_b1(1:end-1, :);
b1 = MT1_b1(end, :);

%% Assuming W and b are already computed during training phase
%phi_test = sqrt(2/D) * [cos(TestX * W + b)];
phi_test = sqrt(2 / D) * cos(W'*TestX'  + b');  % Transform test data using the same W and b
mat_test=phi_test'* phi_tr';

% Compute raw scores for classification
raw = mat_test * h1 + b1;

%% Perform classification (1 for positive, -1 for negative)
assigned_label = zeros(size(raw, 1), 1);
for i = 1:size(raw, 1)
    if raw(i) >= 0
        assigned_label(i) = 1;  % Assign label 1 if score is non-negative
    else
        assigned_label(i) = -1; % Assign label -1 if score is negative
    end
end

% Compute accuracy
accuracy = sum(assigned_label == obs1) / length(obs1) * 100;

% Measure the time taken
Time = toc(start_time);
end