function selected_idx = InCor(X, M, K, s, sigma, lambda)
%
% INPUTS:
%   X      : N x d data matrix
%   M      : number of samples to select
%   K      : number of clusters
%   s      : Nyström landmarks per cluster
%   sigma  : RBF kernel width
%   lambda : regularization parameter
%
% OUTPUT:
%   selected_idx : indices of chosen samples
%


[N, ~] = size(X);

%% 1) Initial clustering (on small subset)
init_sample =N;% min(20000, N);
Xinit = X(randperm(N, init_sample), :);
opts = statset('MaxIter',100,'Display','off');
[~, centroids] = kmeans(Xinit, K, 'Options', opts, 'Replicates', 2);

%% 2) Assign each point to nearest centroid
cluster_indices = cell(K,1);
batch = round(0.2*N);
for start = 1:batch:N
    last = min(N, start+batch-1);
    D = pdist2(X(start:last,:), centroids);
    [~, c] = min(D, [], 2);
    for j=1:length(c)
        cluster_indices{c(j)}(end+1,1) = start+j-1; 
    end
end

%% 3) Local Nyström leverage per cluster
cluster_candidates = cell(K,1);
cluster_leverages  = cell(K,1);
cluster_sizes      = zeros(K,1);

for i=1:K
    ids = cluster_indices{i};
    if isempty(ids), continue; end
    Xi = X(ids,:);
    [cand, lev] = local_leverage(Xi, ids, s, sigma, lambda);
    cluster_candidates{i} = cand;
    cluster_leverages{i}  = lev;
    cluster_sizes(i)      = numel(ids);
end

%% 4) Allocate per cluster
m_alloc = max(1, round(M * (cluster_sizes / sum(cluster_sizes))));
m_alloc = adjust_allocation(m_alloc, M);

%% 5) Collect selected indices
selected_idx = [];
for i=1:K
    cand = cluster_candidates{i};
    lev  = cluster_leverages{i};
    if isempty(cand), continue; end
    [~, ord] = sort(lev, 'descend');
    pick = cand(ord(1:min(m_alloc(i), numel(cand))));
    selected_idx = [selected_idx; pick]; 
end

% ensure exactly M
if numel(selected_idx) > M
    selected_idx = selected_idx(1:M);
end

end

%% --- Helpers ---
function [cand_idx, leverage] = local_leverage(Xi, ids_global, s, sigma, lambda)
n = size(Xi,1); s_eff = min(s,n);
Z = Xi(randperm(n,s_eff),:);
Kc = rbf_kernel(Xi,Z,sigma);  % n x s
W  = rbf_kernel(Z,Z,sigma) + lambda*eye(s_eff);
U  = W \ Kc';                 % s x n
leverage = sum(Kc'.*U,1)';    % n x 1
[~, ord] = sort(leverage,'descend');
cand_idx = ids_global(ord(1:min(3*s_eff,n)));
leverage = leverage(ord(1:min(3*s_eff,n)));
end

function K = rbf_kernel(A,B,sigma)
sq = pdist2(A,B).^2;
K = exp(-sq/(2*sigma^2));
end

function m_alloc = adjust_allocation(m_alloc, M)
diffM = sum(m_alloc)-M;
while diffM~=0
    if diffM>0
        [~,i] = max(m_alloc);
        if m_alloc(i)>1, m_alloc(i)=m_alloc(i)-1; end
        diffM = diffM-1;
    else
        [~,i] = max(m_alloc);
        m_alloc(i)=m_alloc(i)+1;
        diffM = diffM+1;
    end
end
end
